<?php

/*require "inc/functions.php";
require "inc/global.php";

require "controller/alumno.php";

*/
require "view/plantilla/_header.php";
require "view/plantilla/_top.php";
require "view/grupo.php";
require "view/plantilla/_footer.php";
?>

<!-- Los js para que funcionen data tables 1 para cada vista -->
<script type="text/javascript" src="js/grupo.js"></script>