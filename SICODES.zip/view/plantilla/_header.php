<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>MiEscuela</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">


	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="assets/bootstrap4/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap4/css/notify.css">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap4/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/bootstrap4/fonts/css/font-awesome.min.css">
	
	<link rel="stylesheet" type="text/css" href="assets/DataTables-1.10.16/css/dataTables.bootstrap4.css">
	<link rel="stylesheet" type="text/css" href="assets/Buttons-1.4.2/css/buttons.bootstrap4.css">
	


	
	<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

</head>
<body>
<div class="container-fluid " style="padding: 0px 0px 0px 0px;">