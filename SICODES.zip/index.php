<?php

//require "inc/global.php";

//require "controller/login.php";

require "view/plantilla/_header.php";
//require "view/_top.php";
require "view/login.php";
//require "view/_footer.php";
