<?php

/*require "inc/functions.php";
require "inc/global.php";

require "controller/persona.php";

*/
require "view/plantilla/_header.php";
require "view/plantilla/_top.php";
require "view/mensaje.php";
require "view/plantilla/_footer.php";
?>
<script type="text/javascript" src="js/mensaje.js"></script>
