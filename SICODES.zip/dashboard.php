<?php

/*require "inc/functions.php";
require "inc/global.php";

require "controller/persona.php";

*/
require "view/plantilla/_header.php";
require "view/plantilla/_top.php";
require "view/dashboard.php";
require "view/plantilla/_footer.php";
?>